/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package perpussahyu;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class FrmMenuSiswa extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmMenuSiswa.class.getName());

    public FrmMenuSiswa() {
    initComponents();
    this.setLocationRelativeTo(null);
    tampilData();
    tampilRiwayat();
    
    // Panggil fungsi tanggal otomatis di sini
    setTanggalOtomatis(); 
}
    private void setTanggalOtomatis() {
    // Mengambil tanggal hari ini (Real-time sesuai sistem lokal Indonesia)
    LocalDate hariIni = LocalDate.now();
    
    // Menghitung jatuh tempo (misal otomatis 7 hari dari sekarang)
    LocalDate jatuhTempo = hariIni.plusDays(7);
    
    // Format ke YYYY-MM-DD agar sesuai dengan database MySQL
    DateTimeFormatter formatDatabase = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    // Set ke dalam TextField (Gunakan nama variabel field kamu)
    txtTanggalPinjam.setText(hariIni.format(formatDatabase));    // Sebagai Tgl Pinjam
    txtTanggalKembali.setText(jatuhTempo.format(formatDatabase)); // Sebagai Tgl Kembali
}
    private void tampilRiwayat() {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("No Pinjam");
    model.addColumn("Kode Buku");
    model.addColumn("Judul Buku");
    model.addColumn("Tgl Pinjam");
    model.addColumn("Tgl Kembali"); // Tambahkan kolom ini

    String nis = txtNis.getText().trim();
    if (nis.isEmpty()) {
        tampilriwayat.setModel(model);
        return;
    }

    try {
        Connection conn = Koneksi.configDB();
        // Tambahkan p.tgl_kembali ke dalam SELECT
        String sql = "SELECT p.no_pinjam, p.kode_buku, b.JudulBuku, p.tgl_pinjam, p.tgl_kembali " +
                     "FROM tabelpinjam p JOIN tabelbuku b ON p.kode_buku = b.KodeBuku " +
                     "WHERE p.id_siswa = ? AND p.status = 'Dipinjam'";
        
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, nis);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("no_pinjam"),
                rs.getString("kode_buku"),
                rs.getString("JudulBuku"),
                rs.getString("tgl_pinjam"),
                rs.getString("tgl_kembali") // Ambil dari database
            });
        }
        tampilriwayat.setModel(model);
    } catch (Exception e) {
        System.out.println("Gagal memuat riwayat: " + e.getMessage());
    }
}

    // Method untuk menampilkan data dari database ke JTable
    private void tampilData() {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Kode Buku");
    model.addColumn("Judul Buku");
    model.addColumn("Pengarang");
    model.addColumn("Penerbit"); // Tambahan
    model.addColumn("Kategori"); // Tambahan
    model.addColumn("Stok");

    try {
        Connection conn = Koneksi.configDB();
        String sql = "SELECT * FROM tabelbuku"; 
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("KodeBuku"),
                rs.getString("JudulBuku"),
                rs.getString("Pengarang"),
                rs.getString("Penerbit"),
                rs.getString("kategori"),
                rs.getString("Stok")
            });
        }
        jTable1.setModel(model);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Gagal memuat data tabel: " + e.getMessage());
    }
}
    private void cariData(String key) {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Kode Buku");
    model.addColumn("Judul Buku");
    model.addColumn("Pengarang");
    model.addColumn("Penerbit");
    model.addColumn("Kategori");
    model.addColumn("Stok");

    try {
        Connection conn = Koneksi.configDB();
        // SQL ini mencari di SEMUA kolom penting
        String sql = "SELECT * FROM tabelbuku WHERE "
                   + "KodeBuku LIKE ? OR "
                   + "JudulBuku LIKE ? OR "
                   + "Pengarang LIKE ? OR "
                   + "Penerbit LIKE ? OR "
                   + "kategori LIKE ?";
        
        PreparedStatement pst = conn.prepareStatement(sql);
        String search = "%" + key + "%";
        
        for(int i=1; i<=5; i++) {
            pst.setString(i, search);
        }

        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("KodeBuku"),
                rs.getString("JudulBuku"),
                rs.getString("Pengarang"),
                rs.getString("Penerbit"),
                rs.getString("kategori"),
                rs.getString("Stok")
            });
        }
        jTable1.setModel(model);
    } catch (Exception e) {
        System.err.println("Error Cari: " + e.getMessage());
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtNis = new javax.swing.JTextField();
        txtNama = new javax.swing.JTextField();
        txtAlamat = new javax.swing.JTextField();
        txtTanggalPinjam = new javax.swing.JTextField();
        txtTanggalKembali = new javax.swing.JTextField();
        cbKelas = new javax.swing.JComboBox<>();
        btnKembalikan = new javax.swing.JButton();
        btnPinjam = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tampilriwayat = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        txtCari = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 48)); // NOI18N
        jLabel1.setText("Form Siswa");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(360, 360, 360)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jLabel2.setText("NIS");

        jLabel3.setText("Nama");

        jLabel4.setText("Alamat");

        jLabel5.setText("Tanggal Pinjam");

        jLabel6.setText("Tanggal Kembali");

        jLabel7.setText("Kelas");

        cbKelas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "==Pilih Kelas==", "X RPL 1", "X RPL 2", "X TKJ 1", "X TKJ 2", "X TJAT 1", "X TJAT 2", "X ANIMASI 1", "X ANIMASI 2", "XI RPL 1", "XI RPL 2", "XI TKJ 1", "XI TKJ 2", "XI TJAT 1", "XI TJAT 2", "XI ANIMASI 1", "XI ANIMASI 2", "XII RPL 1", "XII RPL 2", "XII TKJ 1", "XII TKJ 2", "XII TJAT 1", "XII TJAT 2", "XII ANIMASI 1", "XII ANIMASI 2" }));

        btnKembalikan.setText("Kembalikan");
        btnKembalikan.addActionListener(this::btnKembalikanActionPerformed);

        btnPinjam.setText("Pinjam");
        btnPinjam.addActionListener(this::btnPinjamActionPerformed);

        btnKeluar.setText("Keluar");
        btnKeluar.addActionListener(this::btnKeluarActionPerformed);

        tampilriwayat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tampilriwayat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tampilriwayatMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tampilriwayat);

        jLabel8.setText("Cari");

        txtCari.addActionListener(this::txtCariActionPerformed);
        txtCari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCariKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTanggalKembali, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTanggalPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtNis, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbKelas, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnKembalikan, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(75, 75, 75)
                                .addComponent(btnKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 544, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(165, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtNis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPinjam))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnKembalikan))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnKeluar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtTanggalPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtTanggalKembali, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(cbKelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel6.getAccessibleContext().setAccessibleName("Tanggal Lahir");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addGap(16, 16, 16))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(216, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKeluarActionPerformed
        new FormLogin().show();
        this.dispose();
    }//GEN-LAST:event_btnKeluarActionPerformed

    private void btnPinjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPinjamActionPerformed

    int baris = jTable1.getSelectedRow();
    if (baris == -1) {
        JOptionPane.showMessageDialog(this, "Pilih buku di tabel!");
        return;
    }

    try {
        // Ambil Kode Buku dari kolom index 0
        String kodeBuku = jTable1.getValueAt(baris, 0).toString();
        
        // FINAL FIX: Stok ada di kolom index 5. 
        // Index 3 berisi "Penerbit" (Informatika), itu penyebab error sebelumnya.
        int stokSekarang = Integer.parseInt(jTable1.getValueAt(baris, 5).toString());
        
        String nis = txtNis.getText().trim();
        String namaForm = txtNama.getText().trim();
        String kelasForm = cbKelas.getSelectedItem().toString();
        String tglPinjamManual = txtTanggalPinjam.getText().trim(); 
        String tglKembaliManual = txtTanggalKembali.getText().trim(); 

        if (nis.isEmpty() || namaForm.isEmpty() || tglPinjamManual.isEmpty() || tglKembaliManual.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua data (NIS, Nama, Tanggal) harus diisi!");
            return;
        }

        Connection conn = Koneksi.configDB();
        
        // --- VALIDASI SISWA ---
        String sqlCekSiswa = "SELECT * FROM tabelsiswa WHERE nis = ?";
        PreparedStatement pstCek = conn.prepareStatement(sqlCekSiswa);
        pstCek.setString(1, nis);
        ResultSet rsSiswa = pstCek.executeQuery();

        if (rsSiswa.next()) {
            String namaDb = rsSiswa.getString("nama");
            String kelasDb = rsSiswa.getString("kelas");
            
            if (!namaForm.equalsIgnoreCase(namaDb) || !kelasForm.equalsIgnoreCase(kelasDb)) {
                JOptionPane.showMessageDialog(this, "Data Nama atau Kelas tidak sesuai dengan database!");
                return;
            }
        } else {
            JOptionPane.showMessageDialog(this, "NIS tidak terdaftar!");
            return;
        }

        // --- PROSES PINJAM ---
        if (stokSekarang > 0) {
            String sqlPinjam = "INSERT INTO tabelpinjam (no_pinjam, tgl_pinjam, tgl_kembali, id_siswa, kode_buku, jumlah, status) VALUES (?, ?, ?, ?, ?, 1, 'Dipinjam')";
            PreparedStatement pst = conn.prepareStatement(sqlPinjam);
            pst.setString(1, "PJ-" + System.currentTimeMillis() % 100000);
            pst.setString(2, tglPinjamManual);
            pst.setString(3, tglKembaliManual);
            pst.setString(4, nis);
            pst.setString(5, kodeBuku);
            pst.execute();

            // Update Stok di database menggunakan nama tabel 'tabelbuku' sesuai instruksi
            String sqlUpdateStok = "UPDATE tabelbuku SET Stok = Stok - 1 WHERE KodeBuku = ?";
            PreparedStatement pstUpdate = conn.prepareStatement(sqlUpdateStok);
            pstUpdate.setString(1, kodeBuku);
            pstUpdate.execute();

            JOptionPane.showMessageDialog(null, "Peminjaman Berhasil!");
            tampilData();
            tampilRiwayat();
        } else {
            JOptionPane.showMessageDialog(null, "Stok buku ini sedang habis!");
        }
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Kesalahan: Data stok di tabel bukan angka!");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Terjadi Kesalahan: " + e.getMessage());
    }
    }//GEN-LAST:event_btnPinjamActionPerformed

    private void btnKembalikanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembalikanActionPerformed
        int baris = tampilriwayat.getSelectedRow();
    if (baris == -1) {
        JOptionPane.showMessageDialog(this, "Pilih data di tabel Riwayat!");
        return;
    }

    String noPinjam = tampilriwayat.getValueAt(baris, 0).toString();
    String kodeBuku = tampilriwayat.getValueAt(baris, 1).toString();

    if (JOptionPane.showConfirmDialog(this, "Kembalikan buku ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
        try {
            Connection conn = Koneksi.configDB();
            
            // 1. Ambil data tgl_kembali (jatuh tempo manual) dari tabelpinjam
            String sqlCek = "SELECT tgl_kembali FROM tabelpinjam WHERE no_pinjam = ?";
            PreparedStatement pstCek = conn.prepareStatement(sqlCek);
            pstCek.setString(1, noPinjam);
            ResultSet rs = pstCek.executeQuery();
            
            long denda = 0;
            if (rs.next()) {
                java.sql.Date tglJatuhTempo = rs.getDate("tgl_kembali");
                java.util.Date tglSekarang = new java.util.Date(); // Waktu Indonesia saat ini
                
                // Hitung selisih hari: (Hari Ini - Jatuh Tempo)
                long diffInMillies = tglSekarang.getTime() - tglJatuhTempo.getTime();
                long selisihHari = diffInMillies / (24 * 60 * 60 * 1000);

                // Jika selisih lebih dari 0 hari, maka denda berlaku
                if (selisihHari > 0) {
                    denda = selisihHari * 2000; // Contoh: Rp 2.000 per hari
                }
            }

            // 2. Simpan ke tabelkembali menggunakan tgl_dikembalikan (NOW)
            String sqlKembali = "INSERT INTO tabelkembali (no_kembali, no_pinjam, tgl_dikembalikan, denda) VALUES (?, ?, NOW(), ?)";
            PreparedStatement pstK = conn.prepareStatement(sqlKembali);
            pstK.setString(1, "KB-" + System.currentTimeMillis() % 100000);
            pstK.setString(2, noPinjam);
            pstK.setLong(3, denda);
            pstK.execute();

            // 3. Update status peminjaman dan kembalikan stok
            conn.createStatement().execute("UPDATE tabelpinjam SET status = 'Kembali' WHERE no_pinjam = '" + noPinjam + "'");
            conn.createStatement().execute("UPDATE tabelbuku SET Stok = Stok + 1 WHERE KodeBuku = '" + kodeBuku + "'");

            String statusDenda = (denda > 0) ? "Terlambat! Denda: Rp " + denda : "Tepat Waktu.";
            JOptionPane.showMessageDialog(null, "Buku Berhasil Dikembalikan!\nStatus: " + statusDenda);
            
            tampilData();
            tampilRiwayat();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mengembalikan: " + e.getMessage());
        }
    }
    }//GEN-LAST:event_btnKembalikanActionPerformed

    private void tampilriwayatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tampilriwayatMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tampilriwayatMouseClicked

    private void txtCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCariActionPerformed

    private void txtCariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCariKeyReleased
        cariData(txtCari.getText());
    }//GEN-LAST:event_txtCariKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FrmMenuSiswa().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnKembalikan;
    private javax.swing.JButton btnPinjam;
    private javax.swing.JComboBox<String> cbKelas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tampilriwayat;
    private javax.swing.JTextField txtAlamat;
    private javax.swing.JTextField txtCari;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtNis;
    private javax.swing.JTextField txtTanggalKembali;
    private javax.swing.JTextField txtTanggalPinjam;
    // End of variables declaration//GEN-END:variables
}
