/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpussahyu;

/**
 *
 * @author yuman
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Koneksi {
    private static Connection mysqlkoneksi;

    public static Connection configDB() {
        try {
            // Untuk Connector/J 9.x, driver name adalah: com.mysql.cj.jdbc.Driver
            String driver = "com.mysql.cj.jdbc.Driver";
            
            // Sertakan serverTimezone agar tidak terjadi error sinkronisasi waktu
            String url = "jdbc:mysql://localhost:3306/perpustakaan?useSSL=false&serverTimezone=UTC";
            String user = "root";
            String pass = ""; 

            Class.forName(driver);
            mysqlkoneksi = DriverManager.getConnection(url, user, pass);
            
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Koneksi Gagal: " + e.getMessage());
        }
        
        return mysqlkoneksi;
    }
}