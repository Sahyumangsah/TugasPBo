/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package perpussahyu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * @author yuman
 */
public class FormBuku extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormBuku.class.getName());

    public DefaultTableModel model;
    String kodebuku, judulbuku, pengarang, penerbit, tahunterbit, stok;
    public String userLevel;

    /**
     * Constructor dengan parameter Level
     */
    public FormBuku(String level) {
        this.userLevel = level; // Simpan level dulu
        initComponents(); // Cukup panggil satu kali di sini
        this.setLocationRelativeTo(null);
        
        // Inisialisasi Tabel
        model = new DefaultTableModel();
        tblBuku.setModel(model);
        model.addColumn("Kode Buku");
        model.addColumn("Judul Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Kategori");
        model.addColumn("Stok");

        tampilkanData(); 
        disableInput();
        aturHakAkses();
    }

    // Constructor default
    public FormBuku() {
        this("Petugas");
    }

    private void aturHakAkses() {
    if (userLevel.equalsIgnoreCase("Siswa") || userLevel.equalsIgnoreCase("User")) {
        btnTambah.setEnabled(false);
        btnEdit.setEnabled(false);
        btnHapus.setEnabled(false); // <--- Tombol dimatikan di sini
        btnSimpan.setEnabled(false);
    }
}

    private void disableInput() {
        txtKodebuku.setEnabled(false);
        txtJudulbuku.setEnabled(false);
        txtPengarang.setEnabled(false);
        txtPenerbit.setEnabled(false);
        txtTahunterbit.setEnabled(false);
        txtKategori.setEnabled(false);
        txtStok.setEnabled(false);
        btnEdit.setEnabled(false);
        btnSimpan.setEnabled(false);
        btnHapus.setEnabled(false);
    }


    public void isiankosong() {
        txtKodebuku.setText("");
        txtJudulbuku.setText("");
        txtPengarang.setText("");
        txtPenerbit.setText("");
        txtTahunterbit.setText("");
        txtKategori.setText("");
        txtStok.setText("");
        
        if (!userLevel.equalsIgnoreCase("User")) {
            txtKodebuku.setEnabled(true);
            btnSimpan.setEnabled(true);
        }
        btnEdit.setEnabled(false);
        btnHapus.setEnabled(false);
    }

    public void aktifkan (){
        if (!userLevel.equalsIgnoreCase("User")) {
            txtKodebuku.setEnabled(true);
            txtJudulbuku.setEnabled(true);
            txtPengarang.setEnabled(true);
            txtPenerbit.setEnabled(true);
            txtTahunterbit.setEnabled(true);
            txtStok.setEnabled(true);
            txtKategori.setEnabled(true);
        }
    }

    public void tampilkanData() {
        model.setRowCount(0); 
        try {
            Connection conn = Koneksi.configDB();
            String sql = "SELECT * FROM tabelbuku";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("KodeBuku"),
                    rs.getString("JudulBuku"),
                    rs.getString("Pengarang"),
                    rs.getString("Penerbit"),
                    rs.getString("TahunTerbit"),
                    rs.getString("kategori"),
                    rs.getString("Stok")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mengambil data: " + e.getMessage());
        }
    }
    public void cariData(String key) {
    model.setRowCount(0); 
    try {
        Connection conn = Koneksi.configDB();
        
        // Query SQL diperbarui dengan menambahkan 'kategori LIKE ?'
        String sql = "SELECT * FROM tabelbuku WHERE "
                   + "KodeBuku LIKE ? OR "
                   + "JudulBuku LIKE ? OR "
                   + "Pengarang LIKE ? OR "
                   + "Penerbit LIKE ? OR "
                   + "TahunTerbit LIKE ? OR "
                   + "kategori LIKE ?"; // Filter kategori ditambahkan
        
        PreparedStatement pst = conn.prepareStatement(sql);
        
        String searchKey = "%" + key + "%";
        
        // Sekarang ada 6 parameter '?' yang harus diisi
        pst.setString(1, searchKey);
        pst.setString(2, searchKey);
        pst.setString(3, searchKey);
        pst.setString(4, searchKey);
        pst.setString(5, searchKey);
        pst.setString(6, searchKey); // Untuk kolom kategori
        
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            // Pastikan urutan kolom sesuai dengan model.addColumn di Constructor
            model.addRow(new Object[]{
                rs.getString("KodeBuku"),
                rs.getString("JudulBuku"),
                rs.getString("Pengarang"),
                rs.getString("Penerbit"),
                rs.getString("TahunTerbit"),
                rs.getString("kategori"), // Kolom kategori muncul sebelum stok
                rs.getString("Stok")
            });
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Gagal Mencari: " + e.getMessage());
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtKodebuku = new javax.swing.JTextField();
        txtJudulbuku = new javax.swing.JTextField();
        txtPenerbit = new javax.swing.JTextField();
        txtPengarang = new javax.swing.JTextField();
        txtStok = new javax.swing.JTextField();
        btnHapus = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnTambah = new javax.swing.JButton();
        btnSimpan = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtTahunterbit = new javax.swing.JTextField();
        txtKategori = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBuku = new javax.swing.JTable();
        txtCari = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 48)); // NOI18N
        jLabel1.setText("FORM BUKU");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(358, 358, 358)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(417, 417, 417))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );

        jLabel2.setText("Kode Buku");

        jLabel3.setText("Judul Buku");

        jLabel4.setText("Penerbit");

        jLabel5.setText("Pengarang");

        jLabel6.setText("Stok");

        btnHapus.setText("Hapus");
        btnHapus.addActionListener(this::btnHapusActionPerformed);

        btnEdit.setText("Edit");
        btnEdit.addActionListener(this::btnEditActionPerformed);

        btnTambah.setText("Tambah");
        btnTambah.addActionListener(this::btnTambahActionPerformed);

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(this::btnSimpanActionPerformed);

        btnKeluar.setText("Keluar");
        btnKeluar.addActionListener(this::btnKeluarActionPerformed);

        jLabel7.setText("Tahun Terbit");

        jLabel9.setText("Kategori");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(234, 234, 234)
                        .addComponent(btnHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtKategori, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtStok, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtKodebuku, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtJudulbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtPenerbit, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtPengarang, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtTahunterbit, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addGap(279, 279, 279))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtKodebuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtJudulbuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtPenerbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtPengarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtTahunterbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtStok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtKategori, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnHapus)
                    .addComponent(btnEdit)
                    .addComponent(btnTambah)
                    .addComponent(btnSimpan)
                    .addComponent(btnKeluar)))
        );

        tblBuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblBuku.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBukuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBuku);

        txtCari.setToolTipText("");
        txtCari.addActionListener(this::txtCariActionPerformed);
        txtCari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCariKeyReleased(evt);
            }
        });

        jLabel8.setText("CARI ⌕");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 9, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        txtCari.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKeluarActionPerformed
        new FormLogin().show();
        this.dispose();
    }//GEN-LAST:event_btnKeluarActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        try {
        // 1. Ambil data dari textfield
        kodebuku = txtKodebuku.getText().trim();
        judulbuku = txtJudulbuku.getText().trim();
        penerbit = txtPenerbit.getText().trim();
        pengarang = txtPengarang.getText().trim();
        tahunterbit = txtTahunterbit.getText().trim();
        String kategori = txtKategori.getText().trim(); // Ambil input kategori
        stok = txtStok.getText().trim();

        // 2. Validasi sederhana (Kategori wajib diisi)
        if (kodebuku.isEmpty() || judulbuku.isEmpty() || kategori.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kode, Judul, dan Kategori tidak boleh kosong!");
            return;
        }

        // 3. Query SQL (Ditambahkan kolom kategori dan satu parameter tanda tanya)
        String sql = "INSERT INTO tabelbuku (KodeBuku, JudulBuku, Penerbit, Pengarang, TahunTerbit, kategori, Stok) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = Koneksi.configDB();
        PreparedStatement pst = conn.prepareStatement(sql);
        
        // 4. Set parameter (Urutan harus sama dengan query SQL di atas)
        pst.setString(1, kodebuku);
        pst.setString(2, judulbuku);
        pst.setString(3, penerbit);
        pst.setString(4, pengarang);
        pst.setString(5, tahunterbit);
        pst.setString(6, kategori); // Set kategori ke parameter ke-6
        pst.setString(7, stok);     // Stok jadi parameter ke-7

        // 5. Eksekusi
        pst.execute();
        
        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        
        // 6. Refresh tampilan
        tampilkanData();
        isiankosong();
        disableInput(); // Opsional: matikan input kembali setelah simpan
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error Simpan: " + e.getMessage());
    }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        isiankosong();
        aktifkan();
        txtKodebuku.requestFocus();
    }//GEN-LAST:event_btnTambahActionPerformed

    private void tblBukuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBukuMouseClicked
                                 
    int baris = tblBuku.rowAtPoint(evt.getPoint());
    
    // Validasi jika baris yang diklik valid (bukan area kosong)
    if (baris != -1) {
        // Ambil data dengan proteksi toString() untuk menghindari NullPointerException
        String kode = model.getValueAt(baris, 0) == null ? "" : model.getValueAt(baris, 0).toString();
        String judul = model.getValueAt(baris, 1) == null ? "" : model.getValueAt(baris, 1).toString();
        String pengarang = model.getValueAt(baris, 2) == null ? "" : model.getValueAt(baris, 2).toString();
        String penerbit = model.getValueAt(baris, 3) == null ? "" : model.getValueAt(baris, 3).toString();
        String tahun = model.getValueAt(baris, 4) == null ? "" : model.getValueAt(baris, 4).toString();
        String kategori = model.getValueAt(baris, 5) == null ? "" : model.getValueAt(baris, 5).toString(); 
        String stok = model.getValueAt(baris, 6) == null ? "" : model.getValueAt(baris, 6).toString();

        // Set data ke masing-masing TextField
        txtKodebuku.setText(kode);
        txtJudulbuku.setText(judul);
        txtPengarang.setText(pengarang);
        txtPenerbit.setText(penerbit);
        txtTahunterbit.setText(tahun);
        txtKategori.setText(kategori); 
        txtStok.setText(stok);

        // Atur status komponen (Tombol & Field)
        aktifkan();
        txtKodebuku.setEnabled(false); // Kode buku biasanya Primary Key, jadi jangan biarkan diedit
        btnSimpan.setEnabled(false);   // Matikan simpan karena ini mode Edit/Hapus
        btnEdit.setEnabled(true);      // Aktifkan tombol Edit
        btnHapus.setEnabled(true);     // Aktifkan tombol Hapus
    }
    }//GEN-LAST:event_tblBukuMouseClicked

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
                                 
    try {
        // Tambahkan kategori=? ke dalam query
        String sql = "UPDATE tabelbuku SET JudulBuku=?, Penerbit=?, Pengarang=?, Tahunterbit=?, kategori=?, Stok=? WHERE KodeBuku=?";
        
        Connection conn = Koneksi.configDB();
        PreparedStatement pst = conn.prepareStatement(sql);
        
        pst.setString(1, txtJudulbuku.getText());
        pst.setString(2, txtPenerbit.getText());
        pst.setString(3, txtPengarang.getText());
        pst.setString(4, txtTahunterbit.getText());
        pst.setString(5, txtKategori.getText()); // Parameter kategori
        pst.setString(6, txtStok.getText());     // Stok jadi parameter ke-6
        pst.setString(7, txtKodebuku.getText()); // KodeBuku jadi parameter ke-7 (WHERE)

        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
        
        tampilkanData(); // Refresh tabel agar kategori muncul
        isiankosong();   
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Gagal Edit: " + e.getMessage());
    }
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
    int jawab = JOptionPane.showConfirmDialog(null, "Hapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
    if (jawab == JOptionPane.YES_OPTION) {
        try {
            String sql = "DELETE FROM tabelbuku WHERE KodeBuku=?";
            
            Connection conn = Koneksi.configDB();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtKodebuku.getText());
            
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
            
            tampilkanData();
            isiankosong();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal Hapus: " + e.getMessage());
        }
    }

    }//GEN-LAST:event_btnHapusActionPerformed

    private void txtCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCariActionPerformed

    private void txtCariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCariKeyReleased
        String key = txtCari.getText().trim(); // Tambahkan .trim() untuk membuang spasi di awal/akhir
    
    if (key.equals("")) {
        tampilkanData(); // Jika kosong, panggil semua data dari tabelbuku
    } else {
        cariData(key);   // Jika ada input, jalankan filter SQL
    }
    }//GEN-LAST:event_txtCariKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FormBuku().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnTambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblBuku;
    private javax.swing.JTextField txtCari;
    private javax.swing.JTextField txtJudulbuku;
    private javax.swing.JTextField txtKategori;
    private javax.swing.JTextField txtKodebuku;
    private javax.swing.JTextField txtPenerbit;
    private javax.swing.JTextField txtPengarang;
    private javax.swing.JTextField txtStok;
    private javax.swing.JTextField txtTahunterbit;
    // End of variables declaration//GEN-END:variables
}
